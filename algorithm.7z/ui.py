#import matplotlib
import os,sys
import tkinter as tk
from tkinter import X
from draw import draw_chart
from data import Data
from sort_ui import bubble_sort
import random
root = tk.Tk()

root.geometry('300x300')
root.resizable(True, True)


message = tk.StringVar()
select = tk.StringVar()

fm = tk.Frame(height=300,width=300)
fm.grid(row=0)
l = tk.Label(fm, text='请选择:')
l.grid()
#label2 = tk.Label(fm2, text='')
#label2.grid()

sort_botton = []
def select_sort():
    b1 = tk.Button(fm, text='冒泡排序', command=run('bubble_sort'), bg='green')
    b1.grid(row=1,column=0,ipadx=20)
    b2 = tk.Button(fm, text='鸡尾酒排序', command='')
    b2.grid(row=1,column=1,ipadx=14)
    b3 = tk.Button(fm, text='选择排序', command='')
    b3.grid(row=1,column=2,ipadx=20)
    b4 = tk.Button(fm, text='插入排序', command='')
    b4.grid(row=2,column=0,ipadx=20)
    b5 = tk.Button(fm, text='希尔排序', command='')
    b5.grid(row=2,column=1,ipadx=20)
    b6 = tk.Button(fm, text='归并排序', command='')
    b6.grid(row=2,column=2,ipadx=20)
    b7 = tk.Button(fm, text='快速排序', command='')
    b7.grid(row=3,column=0,ipadx=20)
    b8 = tk.Button(fm, text='堆排序', command='')
    b8.grid(row=3,column=1,ipadx=26)
    b9 = tk.Button(fm, text='计数排序', command='')
    b9.grid(row=3,column=2,ipadx=20)
    b10 = tk.Button(fm, text='桶排序', command='')
    b10.grid(row=4,column=0,ipadx=26)
    b11 = tk.Button(fm, text='基数排序', command='')
    b11.grid(row=4,column=1,ipadx=20)
    b12 = tk.Button(fm, text='树排序', command='')
    b12.grid(row=4,column=2,ipadx=26)
    sort_botton.append(b1)
    sort_botton.append(b2)
    sort_botton.append(b3)
    sort_botton.append(b4)
    sort_botton.append(b5)
    sort_botton.append(b6)
    sort_botton.append(b7)
    sort_botton.append(b8)
    sort_botton.append(b9)
    sort_botton.append(b10)
    sort_botton.append(b11)
    sort_botton.append(b12)
search_button = []
def select_search():
    B1 = tk.Button(fm, text='二分查找', command='')
    B1.grid(row=1,column=0,ipadx=20)
    B2 = tk.Button(fm, text='哈希表查找', command='')
    B2.grid(row=1,column=1,ipadx=14)
    B3 = tk.Button(fm, text='23树查找', command='')
    B3.grid(row=1,column=2,ipadx=14)
    B4 = tk.Button(fm, text='红黑树查找', command='')
    B4.grid(row=2,column=0,ipadx=14)
    B5 = tk.Button(fm, text='左倾红黑树查找', command='')
    B5.grid(row=2,column=1,ipadx=2)
    
    search_button.append(B1)
    search_button.append(B2)
    search_button.append(B3)
    search_button.append(B4)
    search_button.append(B5)
    
def select_arg():

    #label2.config(text=select.get() + " argrithm:")
    l.config(text="已选择:")
    if select.get() == 'sort':
        for i in sort_botton:
            i.destroy()
        for i in search_button:
            i.destroy()
        select_sort()
        
    if select.get() == 'search':
        for i in sort_botton:
            i.destroy()
        for i in search_button:
            i.destroy()
        select_search()
def create_original_data(dtype):
    data = []
    if dtype == 'random':
        data = list(range(1, Data.data_count + 1))
        random.shuffle(data)
    elif dtype == 'reversed':
        data = list(range(Data.data_count, 0, -1))
    elif dtype == 'few-unique':
        d = Data.data_count // 4
        for i in range(0, d):
            data.append(d)
        for i in range(d, d*2):
            data.append(d*2)
        for i in range(d*2, d*3):
            data.append(d*3)
        for i in range(d*3, Data.data_count):
            data.append(Data.data_count)
        random.shuffle(data)
    elif dtype == 'almost-sorted':
        data = list(range(1, Data.data_count + 1))
        a = random.randint(0, Data.data_count - 1)
        b = random.randint(0, Data.data_count - 1)
        while a == b:
            b = random.randint(0, Data.data_count - 1)
        data[a], data[b] = data[b], data[a]
    return data    
def run(s):
    if s == 'bubble_sort':
        od = create_original_data('random')
        #plt, _ = draw_chart(bubble_sort, od, 100)
        #plt.show()
r1 = tk.Radiobutton(fm, text='排序算法', variable=select, value='sort',command=select_arg)
r1.grid(row=0, column=1)
r2 = tk.Radiobutton(fm, text='查找算法',variable=select, value='search', command=select_arg)
r2.grid(row=0, column=2)



root.mainloop()
