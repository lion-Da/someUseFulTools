def binary_search(lst, item, left, right):
    if left == right:
        if lst[left] > item:
            return left
        else:
            return right

        if left > right:
            return left
    
    mid = (left + right )/2

    if lst[mid] == item:
        return mid
    else:
        if lst[mid] > item:
            return binary_search(lst, item, left, mid - 1)
        elif lst[mid] < item:
            return binary_search(lst, item, mid + 1, right)
        else:
            return mid
def insert_search(lst, item, low, high):
    if low == high:
        if lst[low] > lst[high]:
            return low
        else:
            return high
    if left > right:
        return left


    mid = low + (item - lst[low]) // (lst[high] - lst[low]) * (high - low)
    if lst[mid] == item:
        return mid
    else:
        if lst[mid] > item:
            return insert_search(lst, item, low, mid - 1)
        elif lst[mid] < item:
            return insert_search(lst, item, mid + 1, high)
        else:
            return mid
'''
def fibonacci(f):
    f[0] = 0
    f[1] = 1
    for i in range(2,len(f)):
        f[i] = f[i-1] + f[i-2]
    return f
def fib_search(lst, item, n):
    low, high = 0, n-1
    f = [0 for i in range(len(lst))]
    f = fibonacci(f)
    k = 0
    while n > f[k] - 1:
        k += 1
    t = [0 for i in range(f[k] -1)]
    for i in range(len(lst)):
        t[i] = lst[i]
'''

class hash_table:

    def __init__(self, lst, target):
        self.lst = lst
        self.target = target
		self.ht = []
		self.K = [2 ** x for x in range(0,1000)]
    def hash_func(self, key):
        return key % 65535 
    def build_hash_table(self):
        # get lst length
        lens = len(self.lst)
        # malloc lens space
        ht = [[] for i in range(lens)]
        # [ [key, hash] , ... ,]
        for i in range(0, lens):
            if not self.crash(i):
                ht[i].append(i)
                ht[i].append(self.hash_func(self.lst[i]))
            else:
                # double check method ( +-2 +-4 +-8) for easy realise +2 +4 +8
				for k in self.K:
					if not self.crash(i + k):
						ht[i + k].append(i)
						ht[i + k].append(self.hash_func(self.lst[i]))
						break
					else:
						continue
		self.ht = ht
    def add(self, key):
		if not self.crash(key):
			self.ht[i].append(key)
			self.ht[i].append(self.hash_func(key))
		else:
			for k in self.K:
				if not self.crash(i + k):
					self.ht[i + k].append(key)
					self.ht[i + k].append(self.hash_func(key))
					break
				else:
					continue
	def getValue(self, key):
		#return index
		hash = hash_func(key)
		res = []
		for k in self.K:
			if self.ht[hash + k][0] == key:
				res.append(hash + k)
		return res
class TTT_search(object):
    
    path = []

    def __init__(self, data, parent=None):
        self.childs = {}
        self.data = [data]
        self.parent = parent        

    def insert(self, value):
        Node.path = []
        insert_node = self.search(value)
        insert_node.add(value)

    def split(self):
        if self.parent is None and self.childs:
            branch = Node.path.pop()
            newNodeLeft = Node(self.data.pop(0), self)
            newNodeRight = Node(self.data.pop(1), self)                      
            if branch == "left":
               newNodeLeft.childs["left"] = self.childs["left"]
               newNodeLeft.childs["right"] = self.childs["overflow"]
               newNodeRight.childs["left"] = self.childs["mid"]
               newNodeRight.childs["right"] = self.childs["right"]
            elif branch == "mid":
               newNodeLeft.childs["left"] = self.childs["left"]
               newNodeLeft.childs["right"] = self.childs["mid"]
               newNodeRight.childs["left"] = self.childs["overflow"]
               newNodeRight.childs["right"] = self.childs["right"]
            elif branch == "right":
               newNodeLeft.childs["left"] = self.childs["left"]
               newNodeLeft.childs["right"] = self.childs["mid"]
               newNodeRight.childs["left"] = self.childs["right"]
               newNodeRight.childs["right"] = self.childs["overflow"]
            newNodeLeft.childs["left"].parent = newNodeLeft
            newNodeLeft.childs["right"].parent = newNodeLeft
            newNodeRight.childs["left"].parent = newNodeRight
            newNodeRight.childs["right"].parent = newNodeRight
            self.childs["left"] = newNodeLeft
            self.childs["right"] = newNodeRight
            del self.childs["mid"]

        elif self.parent is not None and self.childs:
            branch = Node.path.pop()
            newNode = Node(self.data.pop(), self.parent)
            self.parent.childs["overflow"] = newNode
            if branch == "left":  
                newNode.childs["left"] = self.childs["mid"]
                newNode.childs["right"] = self.childs["right"]
                self.childs["right"] = self.childs["overflow"]
            elif branch == "mid":
                newNode.childs["left"] = self.childs["overflow"]
                newNode.childs["right"] = self.childs["right"]
                self.childs["right"] = self.childs["mid"]
            elif branch == "right":
                newNode.childs["left"] = self.childs["right"]
                newNode.childs["right"] = self.childs["overflow"]
                self.childs["right"] = self.childs["mid"]
            newNode.childs["left"].parent = newNode
            newNode.childs["right"].parent = newNode
            del self.childs["mid"]

        elif self.parent is None and not self.childs:
            self.childs["left"] = Node(self.data.pop(0), self)
            self.childs["right"] = Node(self.data.pop(1), self)   

        elif self.parent is not None and not self.childs:
            self.parent.childs["overflow"] = Node(self.data.pop(), self.parent) 
            
                
    def add(self, value):
        if value not in self.data:
            self.data.append(value)
            self.data.sort()
            if len(self.data) == 3:
                self.split()
                if self.parent is not None:
                    self.parent.add(self.data.pop())
            else:
                if "overflow" in self.childs:
                    branch = Node.path.pop()
                    if branch == "left":
                        self.childs["mid"] = self.childs["overflow"]
                    elif branch == "right":
                        self.childs["mid"] = self.childs["right"]
                        self.childs["right"] = self.childs["overflow"]
                    del self.childs["overflow"]

    def search(self, value):   
        if self.childs:
            boundLeft = min(self.data)
            boundRight = max(self.data)
            if value < boundLeft:
                Node.path.append("left")
                return self.childs["left"].search(value)
            elif value > boundRight:
                Node.path.append("right")
                return self.childs["right"].search(value)
            else:
                Node.path.append("mid")
                return self.childs["mid"].search(value)
        else:
             return self 

    def element(self, value):
        if value in self.data:
            return True
        elif self.childs:
            boundLeft = min(self.data)
            boundRight = max(self.data)
            if value < boundLeft:
                return self.childs["left"].element(value)
            elif value > boundRight:
                return self.childs["right"].element(value)
            else:
                return self.childs["mid"].element(value)
        else:
            return False







