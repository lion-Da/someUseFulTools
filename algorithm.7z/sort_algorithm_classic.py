#!/usr/bin/env python
# coding: utf-8

# In[147]:


import math
import numpy as np
# 冒泡排序
def bubble_sort(nums):
    for i in range(len(nums) - 1):  # 这个循环负责设置冒泡排序进行的次数
        for j in range(len(nums) - i - 1):  # j为列表下标
            if nums[j] > nums[j + 1]:
                nums[j], nums[j + 1] = nums[j + 1], nums[j]
    return nums
# 鸡尾酒排序 定向冒泡
def cocktail_sort(nums):
    l = len(nums)
    for i in xrange(len(nums), 0, -1):
        rem_i_l_len = abs(i - l)
        isNeedContinue = False
        obverse_count = len(nums[rem_i_l_len : i - 1])
        reverse_count = len(nums[rem_i_l_len + 1 : i - 1])
        
        for j in xrange(obverse_count):
            if nums[j] > nums[j + 1]:
                    nums[j], nums[j + 1] = nums[j + 1], nums[j]
                    isNeedContinue = True
                    
        for j in xrange(reverse_count, 0, -1):
            if nums[j] < nums[j - 1]:
                nums[j], nums[j - 1] = nums[j - 1], nums[j]
                isNeedContinue = True
        if isNeedContinue:
            continue
        else:
            return
# 选择排序
def selection_sort(nums):
    for i in range(len(nums) - 1):
        minIndex = i
        for j in range(i + 1, len(nums)):
            if nums[j] < nums[minIndex]:
                minIndex = j
        nums[minIndex], nums[i] = nums[i], nums[minIndex]
    return nums

# 插入排序
def insert_sort(nums):
    for i in range(1, len(nums)):
        prev = i - 1
        cur = nums[i]
        while prev >= 0 and nums[prev] > cur:
            prev -= 1
        del(nums[i])
        nums.insert(prev + 1, cur)
        
    return nums
# 希尔排序 缩小增量排序。
def shell_sort(nums):
    gap = 1
    while gap < math.floor(len(nums) / 3):
        gap = gap * 3 + 1
    
    while gap > 0:     
        for i in range(gap, len(nums)):
            j = i - gap
            t = nums[i]
            while j >= 0 and nums[j] > t:          # bug
                nums[j + gap] = nums[j]
                j -= gap
            nums[j + gap] = t
        gap = math.floor(gap / 3)
    return nums
# 归并排序
def merge_sort(nums):
    if len(nums) < 2:
        return nums
    mid = math.floor(len(nums) / 2)
    left = nums[0 : mid]
    right = nums[mid: ]
    return merge(merge_sort(left), merge_sort(right))

def merge(left, right):
    res = []
    while len(left) > 0 and len(right) > 0:
        if left[0] <= right[0]:
            res.append(left.pop(0))
        else:
            res.append(right.pop(0))
    while len(left):
        res.append(left.pop(0))
    while len(right):
        res.append(right.pop(0))
    return res
# 快排
def quick_sort(nums, left, right):
    if left < right:
        part = partition(nums, left, right)
        quick_sort(nums, left, part)
        quick_sort(nums, part+1, right)
        
    return nums

def partition(nums, left, right):
    pivot = left
    index = pivot + 1
    for i in range(index, right):
        if nums[i] < nums[pivot]:
            nums[i], nums[index] = nums[index], nums[i]
            index += 1
    nums[pivot], nums[index - 1] = nums[index - 1], nums[pivot]
    return index - 1
# 堆排
lens = 0
def heap_sort(nums):
    global lens
    build_max_heap(nums)
    for i in range(len(nums) - 1, 0, -1):
        nums[0], nums[i] = nums[i], nums[0]
        lens -= 1
        heapify(nums, 0)
    return nums
# 大顶堆建立
def build_max_heap(nums):
    global lens
    lens = len(nums)
    for i in range(math.floor(len(nums) / 2), -1, -1):
        heapify(nums, i)
# 堆调整
def heapify(nums, i):
    global lens
    left = 2 * i 
    right = 2 * i + 1
    largest = i

    if left < lens and nums[left] > nums[right]:
        largest = left
        
    
    if right < lens and nums[right] > nums[largest]:
        largest = right
        
    if largest != i:
        nums[i], nums[largest] = nums[largest], nums[i]
        heapify(nums, largest)
# 计数排序
def counting_sort(nums, max_value):
    bucket = [0] * (max_value + 1)
    sort_index = 0
    for i in range(0, len(nums)):
        if not bucket[nums[i]]:
            bucket[nums[i]] = 0
        bucket[nums[i]] += 1
        
    for j in range(0, len(bucket)):
        while(bucket[j] > 0):
            nums[sort_index] = j
            bucket[j] -= 1
            sort_index += 1
    return nums

# 桶排序
def bucket_sort(nums, bucket_size):
    if len(nums) == 0:
        return nums
    min_value = min(nums)
    max_value = max(nums)
    '''
    for i in range(1, len(nums)):
        if nums[i] < min_value:
            min_value = nums[i]
        elif nums[i] > max_value:
            max_value = nums[i]
    '''
    # 初始化桶
    DEFAULT_BUCKET_SIZE = 5
    bucket_size = bucket_size | DEFAULT_BUCKET_SIZE
    bucket_count = math.floor((max_value - min_value) / bucket_size) + 1
    buckets = [[] for i in range(bucket_count)]

    # 映射函数分配数据到桶
    for i in range(0, len(nums)):
        buckets[math.floor((nums[i] - min_value) / bucket_size)].append(nums[i])

    res = []
    # 排序每个桶，这里使用插入
    for j in range(0, len(buckets)):
        insert_sort(buckets[j])
        for k in range(0, len(buckets[j])):
            res.append(buckets[j][k])
    return res
#基数排序
counter = []
def radix_sort(nums, d):
    for k in range(0, d):#d轮排序
        s=[[] for i in range(0,10)]#因为每一位数字都是0~9，故建立10个桶
        for i in nums:
            s[i//(10**k)%10].append(i) #977/10=97(小数舍去),87/100=0
        nums=[j for i in s for j in i]
    return nums

a = [4,5,7,1,23,45,6,3,2,13,32,31,33,1024,2045,212,1023,1024,1022]
print(radix_sort(a, len(a)))


# In[ ]:




