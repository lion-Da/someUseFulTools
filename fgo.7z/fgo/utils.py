#!/usr/bin/env python
# coding: utf-8

# In[36]:

from battle import *
import pyautogui as pag
from time import sleep
pag.PAUSE = 1.5
pag.FAILSAFE = True
Iapple = 0
def eatApple():
    global Iapple
    apple = ['Aapple.png', 'Sapple.png', 'Gapple.png']
    if Iapple > 2:
        return -1, -1
    # get (x,y) of plus.png
    pos = pag.locateOnScreen('plus.png')
    x, y = pag.center(pos)
    pag.click(x, y)
    # select apple
    pos = pag.locateOnScreen(apple[Iapple])
    x, y = pag.center(pos)
    pag.click(x, y)
    # eat apple
    pos = pag.locateOnScreen('eatAppleOk.png')
    if pos == None:
        # eat other apple
        Iapple += 1
        return Iapple, 0
    else:
        x, y = pag.center(pos)
        pag.click(x, y)
def checkAppleForStage():
    # 吃金银铜苹果 当进入关卡没体力时
    # 都不满足说明有体力自然跳过
    if pag.pixelMatchesColor(410, 579, (234, 226, 217)):
        pag.click(410, 579)
        sleep(1)
        pag.click((844, 579))
        print('吃铜苹果')
    elif pag.pixelMatchesColor(402, 473, (224, 248, 248)):
        pag.click(402, 473)
        sleep(1)
        pag.click((844, 579))
        print('吃银。。')

    elif pag.pixelMatchesColor(411,352,(252, 252, 167)):
        pag.click(411,352)
        sleep(1)
        pag.click((844, 579))
        print('吃金。。。')

    
    else:
        print('不吃苹果')
        return 0
#eatApple()
def enterChris():
    # 进入活动
    pag.click(1257, 137)
    sleep(1)
    pag.click(956,389)
    sleep(1)

    # select state
def selectState():
    # 选择关卡
    pag.click(1257, 137)
    sleep(1)
    pag.click(1260, 517)
    sleep(1)
    if checkState():
        pag.click((821, 271))
        sleep(1)
        print('检察活动关卡')

    #选择术助战
def checkState():
    if pag.pixelMatchesColor(788,240,(35, 150, 159)) and pag.pixelMatchesColor(838,240,(43, 158, 158)) and pag.pixelMatchesColor(878, 235, (248, 252, 252)):
        return True
    else:
        return False
def selectCaster():


    sleep(1)
    pag.click((457, 152))
    sleep(1)
def selectALL():
    sleep(1)
    pag.click((132, 150))
    sleep(1)
def freshList():
    # 刷新助战

    pag.click(850,152)
    sleep(1)
    pag.click(827,566)
    sleep(1)

def selectHelper():
    # 选择助战为满破礼装孔明 翻页为三 优先选择好友的
    # 第一页
    '''
    pag.click(1243,199)
    
    pag.click(1243,348)
    pag.click(1243,453)
    '''
    sc = 0
    while sc <= 2:
        if pag.pixelMatchesColor(229,341,(242,202,127)) and pag.pixelMatchesColor(228,373,(253,253,66)):
            pag.click((229,341))
            return 'find'
        elif pag.pixelMatchesColor(229,535,(244,204,129)) and pag.pixelMatchesColor(229,565,(246,246,80)):
            pag.click((229,535))
            return 'find'
        else:
            sc += 1
            sleep(10)
            print('该页无满破孔明，将刷新助战')
            freshList()
            sleep(1)
    while 6 > sc > 2:
        if pag.pixelMatchesColor(229,341,(242,202,127)) and pag.pixelMatchesColor(228,373,(253,253,66)):
            pag.click((229,341))
            return 'find'
        elif pag.pixelMatchesColor(229,535,(244,204,129)) and pag.pixelMatchesColor(229,565,(246,246,80)):
            pag.click((229,535))
            return 'find'
        elif pag.pixelMatchesColor(229,341,(242,202,127)) and pag.pixelMatchesColor(228,373,(73, 21, 58)):
            pag.click((229,341))
            return 'find'
        elif pag.pixelMatchesColor(229,535,(244,204,129)) and pag.pixelMatchesColor(229,565,(96, 5, 54)):
            pag.click((229,535))
            return 'find'
        else:
            sc += 1
            sleep(10)
            print('该页也无未满破孔明，将刷新助战')
            freshList()
            sleep(1)
    return 'nofind'
    # 记录满破礼装孔明的rgb 首先固定位置

def startBattle():
    pos = pag.locateOnScreen('startBattle.png')
    x, y = pag.center(pos)
    pag.click(x, y)
    
def utils():
    #eatApple()
    enterChris()
    sleep(1)
    selectState()
    sleep(1)
    a = selectHelper()
    while a == 'nofind':
        sleep(5)
        freshList()
        sleep(1)
        a = selectHelper()
    sleep(1)
    startBattle()

                




