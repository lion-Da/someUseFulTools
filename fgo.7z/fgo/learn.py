from time import sleep
import pyautogui as pag

l2 = []
a = input()
def c(p):
    pag.click(p)
    sleep(1)
try:
    while True:
        x,y = pag.position()

        x,y = 1133,711
        im = pag.screenshot()
        rgb = im.getpixel((x,y))
        print([(x,y),rgb])
        if [(x,y),rgb] not in l2 and rgb[0] == rgb[1] == rgb[2]:
            l2.append([(x,y),rgb])
except KeyboardInterrupt:
    print('fin')
    '''
    with open('1.txt', 'w') as f:
        for item in l2:
            f.write("%s\n" % item)
    f.close()
    '''
    
"""
a = input()
l2 = []
def freshList():
    # 刷新助战

    pag.click(850,152)
    sleep(1)
    pag.click(827,566)
    sleep(1)

sleep(1)
skillx = [(228,373),(229,565)]
skilly = 587
nativeSkill = []

try:
    im = pag.screenshot()

    for x in skillx:

        rgb = im.getpixel(x)
        pag.moveTo(x)
        print([x,rgb])
        nativeSkill.append(rgb)
        '''
        if [(x,y),rgb] not in l2 and rgb[0] == rgb[1] == rgb[2]:
            l2.append([(x,y),rgb])
        ''' 
        sleep(1)
    print(nativeSkill)
except KeyboardInterrupt:
    print('fin')
    print(nativeSkill)

"""