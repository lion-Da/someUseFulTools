#!/usr/bin/env python
# coding: utf-8

from battle import *
from utils import *
from battle import GIFT
import winsound
COUNT = 0
import sys
def main():
    # 主逻辑
    global COUNT
    while True:
        battleState = 0
        finish  = 0
        #关卡选择 助战选择满破礼装孔明，体力不够关卡时吃苹果，铜到金顺序
        while not checkState():
            if error_click():
                c((664, 590))
            c((1257, 137))
            c((1260, 517))
            print('检查关卡中')
        selectState()
        checkAppleForStage()
        selectCaster()
        a = selectHelper()
        while a == 'nofind':
            a = selectHelper()
        sleep(1)
        startBattle()
        while battleState == 0:
            # 战斗进入判断 及等待 防未退出关卡bug
            while not judgeBattle():
                if checkState():
                    break
                sleep(1)
                
            if checkState():
                break
            sleep(5)
            #战斗过程
            
            attack()
            # 结束判断及循环
            if battleEnd():
                print('战斗结束')
                battleState = battleFinish()
                while not battleState:
                    # 点击下一步
                    c((1133,711))
                    battleState = battleFinish()
                if battleState == 1:
                    c((1133,711))
                battleState = 0
                finish = 1
            else:
                pass
            if finish == 1:
                break
                
        #返回关卡界面判断
        while not checkState():
            if error_click():
                c((664, 590))
            c((1257, 137))
            c((1260, 517))
            print('检查结束关卡中')
        print('下一轮')
        COUNT += 1
        print("当前已进行轮数：",COUNT)
        print("掉落礼装数：",GIFT)
        if GIFT >= 1:
            winsound.PlaySound('alert', winsound.SND_ASYNC)
            sleep(1)
            winsound.PlaySound('alert', winsound.SND_ASYNC)
            sleep(1)
            winsound.PlaySound('alert', winsound.SND_ASYNC)
            sleep(1)
            sys.exit(0)
        # no auto eat apples
if __name__ == '__main__':
    main()

