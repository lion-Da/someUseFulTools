#!/usr/bin/env python
# coding: utf-8

# In[28]:


import pyautogui as pag
import copy
from time import sleep
import random
class FError(Exception):
    pass
pag.PAUSE = 1.5
pag.FAILSAFE = True
Gr, Gg, Gb = 2, 1, 2
Sr, Sg, Sb = 2, 1, 2
Kr, Kg, Kb = 1, 1, 3
Ar, Ag, Ab = 0, 0, 0
Rr, Rg, Rb = 5, 5, 5
masterSkillStatus = [1,1,1]

CD = [0,0,0,0,0,0,0,0,0]
nowCard = []


GIFT = 0
# 等待直到战斗开始
# 判定出现弓阶则判断进入战斗
def error_click():
    if pag.pixelMatchesColor(664, 590, (161, 161, 161)):
        return True
    else:
        return False
def judgeBattle():
    if pag.pixelMatchesColor(106, 668, (167, 125, 10)):
        return True
    else:
        return False
    
def battleEnd():
    if pag.pixelMatchesColor(131, 211, (233, 183, 35)):
        return True
    else:
        return False
def battleFinish():
    global GIFT
    im = pag.screenshot()
    x,y = 1133,711
    if pag.pixelMatchesColor(391, 259, (245, 214, 78)):
        # 掉礼装了
        print('掉礼装了')
        GIFT += 1
    if  pag.pixelMatchesColor(1133,711, (238,238,238)):
        print('finish a battle')
        return 1
    else:
        return 0
    
def getCardColor():
    # position 
    im = pag.screenshot()
    positionList = [(965,565), (1003,496), (1058,451), (1132,430), (1209,442)]

    tmprgb = []
    for i in positionList:
        tmprgb.append(im.getpixel(i))
        
    outputrgb = []
    for i in tmprgb:
        r, g, b = i[0], i[1], i[2]
        if max(r,g,b) == r:
            outputrgb.append('r')
        if max(r,g,b) == g:
            outputrgb.append('g')
        if max(r,g,b) == b:
            outputrgb.append('b')
    print('当前卡组卡色',outputrgb)
    return outputrgb
def getCardName():
    im = pag.screenshot()
    tmprgb = []
    plist = [(975,540),(1029,478),(1085,445),(1161,430),(1231,455)]
    for i in plist:
        tmprgb.append(im.getpixel(i))
    outputname = []
    for i in tmprgb:
        r,g,b = i[0],i[1],i[2]
        if r < 100 and g < 100 and b < 100:
            outputname.append('K')
        if abs(g - b) <= 30 and r > 100:
            outputname.append('S')
        if abs(r - g) <= 30 and r > 100 and abs(g-b) > 30:
            outputname.append('G')
    print('当前卡组从者',outputname)
    return outputname
#目标更改
def change_target(state):
    epx = [88, 321, 552]
    epy  = 71
    if state == 2:
        c((epx[0],epy))
    if state == 3:
        c((epx[1],epy))
#技能释放
def release_skill(state, card): 
    global masterSkillStatus
    skillx = [109, 205, 287, 415, 515, 597, 722, 818, 905]
    skilly = 587
    nativeSkill = [(32, 32, 50), (65, 75, 83), (125, 123, 93), (93, 93, 93), (126, 122, 60), (127, 74, 3), (127, 48, 2), (114, 79, 27), (87, 87, 87)]
    master_skillx = [922,998,1091]
    master_skilly = 330
    master = (1198,331)
    ptskillx = [365, 655, 949]
    ptskilly = 473
    cancel = (732,142)
    if state == 1:
        # 第一面 闪闪np率，集星 小黑3技能 孔明一技能
        x = [2,4,5,7]
        for i in x:
            print(i,skillx[i],skilly, nativeSkill[i])
            if not pag.pixelMatchesColor(skillx[i],skilly, nativeSkill[i]):
                c((skillx[i],skilly))
 
        
        if not pag.pixelMatchesColor(skillx[6],skilly, nativeSkill[6]):
            c((skillx[6], skilly))
            # point into 小黑
            c((ptskillx[0],ptskilly))
    if state == 2:
        # 孔明两技能 小黑2技能 闪闪1技能
        x = [1,2,3,4,5,8]
        for i in x:
            if not pag.pixelMatchesColor(skillx[i],skilly, nativeSkill[i]):
                c((skillx[i],skilly))
    
            if not pag.pixelMatchesColor(skillx[6],skilly, nativeSkill[6]):
                c((skillx[6], skilly))
            # point into 闪闪
                c((ptskillx[1],ptskilly))
    if state == 3:
        x = [0,1,2,3,4,5,7,8]
        for i in x:
            if not pag.pixelMatchesColor(skillx[i],skilly, nativeSkill[i]):
                c((skillx[i],skilly))

        if not pag.pixelMatchesColor(skillx[6],skilly, nativeSkill[6]):
            c((skillx[6], skilly))
            # point into 闪闪
            c((ptskillx[1],ptskilly))
            c(cancel)

        # masterkill readying
        if masterSkillStatus[0] == 1:
            c(master)
            c((master_skillx[0],master_skilly))
            c((ptskillx[1],ptskilly))
            c(cancel)
            masterSkillStatus[0] = 0
        if get_card_color_nums(card, 'r', 'G') >=1 and masterSkillStatus[1] == 1 :
            c(master)
            c((master_skillx[1],master_skilly))
            c((ptskillx[1],ptskilly))
            
            masterSkillStatus[1] = 0
        if get_card_color_nums(card, 'b', 'G') >=1 and masterSkillStatus[2] == 1 :
            c(master)
            c((master_skillx[2],master_skilly))
            c((ptskillx[1],ptskilly))
            
            masterSkillStatus[2] = 0

def c(p):
    pag.click(p)
    sleep(1.5)
def check_state_init():
    f1 = open('1.txt','r')
    f2 = open('2.txt','r')
    f3 = open('3.txt','r')
    p1  = f1.readlines()
    p2  = f2.readlines()
    p3  = f3.readlines()
    pix1 = []
    for i in range(len(p1)):
        p1[i] = p1[i].strip('\n').strip('[]').strip('(').partition(')')[0]
        pix1.append((int(p1[i][0:3]), int(p1[i][5:7])))
    pix2 = []
    for i in range(len(p2)):
        p2[i] = p2[i].strip('\n').strip('[]').strip('(').partition(')')[0]
        pix2.append((int(p2[i][0:3]), int(p2[i][5:7])))
    pix3 = []
    for i in range(len(p3)):
        p3[i] = p3[i].strip('\n').strip('[]').strip('(').partition(')')[0]
        pix3.append((int(p3[i][0:3]), int(p3[i][5:7])))
    f1.close()
    f2.close()
    f3.close()
    #print(pix1,len(pix2),len(pix3))
    return pix1,pix2,pix3
def check_state(p1,p2,p3):
    #检查像素点，如果rgb相等则返回state
    im = pag.screenshot()
    try:
        for i in p1:
            rgb = im.getpixel(i)
            r,g,b = rgb[0],rgb[1],rgb[2]
            if r== g == b:
                continue
            else:
                raise FError('nomatch')
        return 1
    except FError as  e:
        try:
            for i in p2:
                rgb = im.getpixel(i)
                r,g,b = rgb[0],rgb[1],rgb[2]
                if r== g == b:
                    continue
                else:
                    raise FError('nomatch')
            return 2
        except FError as e:
            try:
                for i in p3:
                    rgb = im.getpixel(i)
                    r,g,b = rgb[0],rgb[1],rgb[2]
                    if r== g == b:
                        continue
                    else:
                        raise FError('nomatch')
                return 3
            except FError as e:
                return -1

def check_bomb():
    status = [0,0,0]
    p = [(389,195),(720,333),(951,323)]
    im = pag.screenshot()
    for i in p:
        rgb = im.getpixel(i)
        r,g,b = rgb[0],rgb[1],rgb[2]
        print(r,g,b)
        if r > 250 and b > 100 :
            status[0] = 1
            print('S',r,g,b)
        if r > 200 and g < 100 and b < 100:
            status[1] = 1
            print('G',r,g,b)
        if 200 > r > 100 and g < 100 and b < 100:
            status[2] = 1
            print('K',r,g,b)
    return status
def click_attack(s):
    # 传入位置信息 挨个点就行了
    for p in s:
        c(p)
        
def bomb_card_attack(card):
    # 判断传入卡组状态 返回点击坐标
    pattack = [(170,512),(422,512),(672,512),(902,512),(1168,512)]
    bomb = [(457,136),(678,136),(879,136)]
    res = copy.deepcopy(card)
    for i in range(len(card)):
        if type(card[i]) is int:
            res[i] = pattack[card[i]]
        elif type(card[i]) is str:
            if card[i] == 'KB':
                res[i] = bomb[2]
            if card[i] == 'GB':
                res[i] = bomb[1]
            if card[i] == 'SB':
                res[i] = bomb[0]
    print(res)
    return res
def mergeCard():
    cc = getCardColor()
    cn = getCardName()
    if len(cn) < 5:
        count = 5 - len(cn)
        while count > 0:
            cn.append('G')
            count -= 1
    global nowCard
    nowCard = copy.deepcopy([])
    for i in range(5):
        nowCard.append((cn[i], cc[i]))
def updatePosition(l):
    global nowCard
    tmpcard = copy.deepcopy(nowCard)
    tmpsave = []
    for i in range(len(l)):
        if l[i] == ['unselect','unselect'] or l[i] == [0,0]:
            tmpsave.append('random')
            continue
        for j in range(len(tmpcard)):
            if (l[i][0], l[i][1]) == tmpcard[j]:
                tmpsave.append(j)
                tmpcard[j] = ('selected','selected')
                break
    # 对数组进行处理 random修改为非已存在的值
    exsit = []
    A = [0,1,2,3,4]
    random.shuffle(A)
    for i in tmpsave:
        if type(i) is int:
            exsit.append(i)
    B = [i for i in A if i not in exsit]
    for i in range(len(tmpsave)):
        if tmpsave[i] == 'random':
            tmpsave[i] = random.sample(B,1)[0]
            exsit.append(tmpsave[i])
            B = [j for j in A if j not in exsit]
    return tmpsave
def get_card_color_nums(card, color, name):
    return len([color for i in enumerate(card) if (i[1][1] == color and i[1][0] == name) ])


def method_np_G():
    resCard = [[0,0],[0,0],[0,0]]
    global nowCard
    print(nowCard,get_card_color_nums(nowCard, 'b','G'))
    bluecardlist = [i for i in nowCard if i[1] == 'b']
    redcardlist = [i for i in nowCard if i[1] == 'r']
    greencardlist = [i for i in nowCard if i[1] == 'g']
    if get_card_color_nums(nowCard, 'b','G') == 2:
        # 卡池两张金先生蓝卡
        resCard[1] = ['G','b']
        resCard[2] = ['G','b']
        if len(bluecardlist) >= 3:
            remain_blue = [i for i in bluecardlist if i[0] != 'G']
            if ('S','b') in remain_blue:
                resCard[0] = ['S','b']
            else:
                resCard[0] = ['K','b']
        else:
            # 卡池只有两张金先生蓝卡，则选红卡开头为了鞭尸+np
            # 顺序为 金先生 > 小黑 > 孔明
            if ('G', 'r') in redcardlist:
                resCard[0] = ['G','r']
            elif ('S', 'r') in redcardlist:
                resCard[0] = ['S','r']
            elif ('K','r') in redcardlist:
                resCard[0] = ['K','r']
            else:
                # 卡池没有红卡。。。。选张绿卡
                if ('G','g') in greencardlist:
                    resCard[0] = ['G','g']
                elif ('S','g') in greencardlist:
                    resCard[0] = ['S','g']
                elif ('K','g') in greemcardlist:
                    resCard[0] = ['K','g']
                else: 
                    # 没卡了 卧槽？？？
                    resCard[0] = ['unselect','unselect']
                    
    if get_card_color_nums(nowCard, 'b','G') == 1:
        # 卡池有金先生蓝卡 确定为第三位置
        resCard[2] = ['G','b']
        # 要首蓝
        if len(bluecardlist) >= 3:
            # 三蓝组合
            if get_card_color_nums(bluecardlist, 'b', 'S') == 2:
                resCard[0], resCard[1] = ['S','b'], ['S','b']
            if get_card_color_nums(bluecardlist, 'b', 'S') == 1:
                resCard[0], resCard[1] = ['K','b'], ['S','b']
            if get_card_color_nums(bluecardlist, 'b', 'S') == 0:
                resCard[0], resCard[1] = ['K','b'], ['K','b']
        if len(bluecardlist) == 2:
            # 首蓝 + （闪红，黑绿，黑红，孔绿，孔红） + 尾蓝
            first = [i[0] for i in bluecardlist if i[0] != 'G']
            resCard[0] = [first[0], 'b']
            if ('G','r') in nowCard:
                resCard[1] = ['G','r']
            elif ('S','r') in nowCard:
                resCard[1] = ['S','r']
            elif ('S','g') in nowCard:
                resCard[1] = ['S','g']
            elif ('K','g') in nowCard:
                resCard[1] = ['K','g']
            elif ('K','r') in nowCard:
                resCard[1] = ['K','r']
            else:
                #又没卡 卧槽？
                resCard[1] = ['unselect','unselect']
    if get_card_color_nums(nowCard, 'b','G') == 0:
        #卡池没有金先生蓝卡的话就尽可能选绿卡
        if ('G','g') in greencardlist:
            resCard[2] = ['G','g']
            resCard[1] = ['unselect','unselect']
            #黑蓝 黑绿
            #黑蓝 黑红
            #黑蓝 黑蓝
            #孔蓝 黑蓝
            #孔蓝 黑绿
            #孔蓝 黑红
            
            if get_card_color_nums(nowCard,'r','S') + get_card_color_nums(nowCard,'g','S') + get_card_color_nums(nowCard,'b','S') >= 2:
                if get_card_color_nums(nowCard,'b','S') >= 1:
                    resCard[0] = ['S','b']
                elif ('K','b') in nowCard:
                    resCard[0] = ['K','b']
                else:
                    resCard[0] = ['unselect','unselect']
            else:
                if ('K','b') in nowCard:
                    resCard[0] = ['K','b']
                else:
                    resCard[0] = ['unselect','unselect']
            
        else:
            # xjbd吧 看看有没有三连
            # 先看红卡三连
            if get_card_color_nums(nowCard, 'r', 'G') == 2:
                resCard[0],resCard[2] = ['G','r'], ['G','r']
                if ('S','r') in nowCard:
                    resCard[1] = ['S','r']
                elif ('S','b') in nowCard:
                    resCard[1] = ['S','b']
                elif ('S','g') in nowCard:
                    resCard[1] = ['S','g']
                elif ('K','r') in nowCard:
                    resCard[1] = ['K','r']
                elif ('K','b') in nowCard:
                    resCard[1] = ['K','b']
                elif ('K','g') in nowCard:
                    resCard[1] = ['K','g']
                else:
                    resCard[1] = ['unselect','unselect']
            if get_card_color_nums(nowCard, 'r', 'G') == 1:
                resCard[0] = ['G','r']
                resCard[1],resCard[2] = ['unselect','unselect'],['unselect','unselect']
            if get_card_color_nums(nowCard, 'r', 'G') == 0:
                resCard[1],resCard[2],resCard[0]= ['unselect','unselect'],['unselect','unselect'],['unselect','unselect']
                
    return resCard
def update_card(card, state, bomb_state):
    # 点击atack后 检查宝具是否存在，根据state做出将宝具卡放到卡组中
    # card 为已经attack之前卡组, state为第几面敌人,bomb_state为宝具状态
    if state == 2 and bomb_state[0] == 1:
        # 将小黑宝具放入卡组
        card[0] = 'SB'
    elif state == 3:
        if bomb_state[2] == 1 and bomb_state[0] == 1 and bomb_state[1] == 1:
            card[0],card[1],card[2] = 'KB','GB','SB'
        elif bomb_state[2] == 1 and bomb_state[1] == 1:
            card[0],card[1] = 'KB','GB'
        elif bomb_state[1] == 1 and bomb_state[0] == 1:
            card[0],card[1] = 'GB', 'SB'
        elif bomb_state[0] == 1:
            card[0] = 'SB'
        elif bomb_state[1] == 1:
            card[0] = 'GB'
        else:
            pass
    return card
'''
def method_max_damage(p,card):
    # 金先生宝红红 > 宝蓝红  > 宝绿红 > 宝蓝蓝 > 宝绿蓝 > 红蓝红 > 红绿红 > 红蓝蓝  > 红绿蓝 > 其他三红
    # 小黑 宝蓝蓝 > 宝绿蓝 > 宝绿绿 > 宝红蓝  > 宝红绿 > 宝绿金蓝 > 其他
    # card为添加宝具前的卡组，则第一个金先生为红卡即可
    Sc = [['SB','b','b'],['SB','g','b'],['SB','g','g'],['SB','r','b'],['SB','r','g']]
    if p == 'S':
        nsc = split_card_by(p, card)
        if len(nsc) == 0:
            pass
            
def split_card_by(p,card)：
    return [ i[1][1] for i in card if i[1][0] == p]
'''          
def attack():
    # 小黑是满np的 则让闪闪打np为主， 选择master服为减少cd或单体np+20 都可以,或者给闪闪爆输出
    global nowCard
    mergeCard()
    selected = method_np_G()
    print('选中卡组',selected)
    #根据已选择牌决定出牌位置
    select_pos = updatePosition(selected)
    print('已选卡位置',select_pos)
    
    p1,p2,p3 = check_state_init()
    state = check_state(p1,p2,p3)
    
    print("掉落礼装数：",GIFT)
    sleep(1)
    release_skill(state, selected)
    print('技能释放完毕')
    if state >= 2:
        change_target(state)
    
    print("掉落礼装数：",GIFT)
    c((1135,621))
    bomb_state = check_bomb()
    print('当前阶段数:',state,'宝具状态',bomb_state)
    pp = update_card(select_pos, state, bomb_state)
    print('根据宝具和阶段更新出牌卡组',pp)
    bombnums = 0
    for i in pp:
        if type(i) is not int:
            bombnums += 1
    bca = bomb_card_attack(pp)
    print('最终出牌位置',bca)
    print("掉落礼装数：",GIFT)
    click_attack(bca)
    if state == 1:
        sleep(20)
    if state== 2:
        sleep(20+ bombnums*5)
    if state == 3:
        sleep(25+bombnums*10)



