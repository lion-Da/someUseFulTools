# -*- coding: UTF-8 -*-

import socket
import sys
import os


dir_path = os.path.realpath(__file__)
def clip(name):
    os.system("clip < %s" % name)





HOST = '0.0.0.0'   # Symbolic name, meaning all available interfaces
PORT = 5500 # Arbitrary non-privileged port
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    s.bind((HOST, PORT))
except socket.error as msg:
    print 'Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
    os.execl(sys.executable, ' ' + dir_path, *argv)

    
print 'Socket bind complete'
s.listen(10)
print 'Socket now listening'
#now keep talking with the client
while 1:
    try:
    #wait to accept a connection - blocking call
        f = open('recv.txt', 'w')
        conn, addr = s.accept()
        print 'Connected with ' + addr[0] + ':' + str(addr[1])
        print "recving data..."
    
    
        buf = conn.recv(1024)
        data = ''
        while buf:
            data += buf
            buf = conn.recv(1024)
    
        f.write(data)
        f.close()
        print data
        clip('recv.txt')
    
    except KeyboardInterrupt:
        sys.exit()
    except:
        os.execl(sys.executable, ' ' + dir_path, *argv)

s.close()