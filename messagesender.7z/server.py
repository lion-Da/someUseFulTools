# -*- coding:utf-8 -*-
import socket
import sys
from Tkinter import *

reload(sys)                      # reload 才能调用 setdefaultencoding 方法  
sys.setdefaultencoding('utf-8')  # 设置 'utf-8'  

class ServerUI():

    s = socket.socket()
    
    def __init__(self, master):
        """ init ui """ 
        self.master = master

        frame = Frame(master)
        frame.config(width=320)
        frame.pack()        

        Label(frame, text=u"IP地址").grid(row=0,padx=5,pady=10, sticky=W)
        Label(frame, text=u"端口").grid(row=1,padx=5,sticky=W)

        self.ipaddr = StringVar()
        self.port = IntVar()
        self.ipaddress = Entry(frame, textvariable=self.ipaddr, width=35)
        self.portnum = Entry(frame, textvariable=self.port, width=35)
        self.ipaddress.grid(row=0, column=1,columnspan=3,sticky=W+E)
        self.portnum.grid(row=1, column=1,columnspan=3,sticky=W)
        Label(frame, text=u"发送内容").grid(row=3,padx=5,sticky=W)
        
        self.msg_val = StringVar()
        self.msg = Entry(frame, textvariable=self.msg_val,  width=35)
        self.msg.grid(row=4,columnspan=3,padx=5,pady=6, sticky=W+E)
        
        frame2 = Frame(master, relief=RAISED, borderwidth=1)
        frame2.pack(fill=BOTH, expand=1)

        self.connect = Button(master, text=u" 连接 ", command=self.connect)
        self.send = Button(master, text=u" 发送 ", command=self.sendmessage)
        self.disconnect = Button(master, text=u" 断开连接 ", command=self.disconnect)   
        self.disconnect.pack(side=RIGHT, padx=5, pady=5)
        self.send.pack(side=RIGHT, padx=5, pady=5)        
        self.connect.pack(side=RIGHT, padx=5, pady=5)
        
        
        self.master.protocol("WM_DELETE_WINDOW",self.exit_program)
    


    def exit_program(self):
        sys.exit()
        
    def connect(self):
        self.s = socket.socket()
        HOST = self.ipaddress.get()   # Symbolic name, meaning all available interfaces
        PORT = int(self.portnum.get()) # Arbitrary non-privileged port
        self.s.connect((HOST,PORT))

    def disconnect(self):
        self.s.close()
    def sendmessage(self):
        print self.msg_val.get()
        self.s.sendall(self.msg_val.get().encode('gbk'))

if __name__ == '__main__':
    master = Tk()
    master.title(u"发送消息到对方剪贴版")
    master.maxsize(335,280)
    master.minsize(335,280)
    client = ServerUI(master)
    master.mainloop()